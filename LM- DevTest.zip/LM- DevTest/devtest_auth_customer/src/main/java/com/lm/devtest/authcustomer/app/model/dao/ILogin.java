package com.lm.devtest.authcustomer.app.model.dao;

import org.springframework.data.repository.CrudRepository;

import com.lm.devtest.authcustomer.app.model.entity.User;


public interface ILogin extends CrudRepository<User, Integer> {

}
