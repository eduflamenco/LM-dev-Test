package com.lm.devtest.authcustomer.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevtestAuthCustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevtestAuthCustomerApplication.class, args);
	}

}
