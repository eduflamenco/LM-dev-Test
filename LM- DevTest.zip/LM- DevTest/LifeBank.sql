create database LifeBank;

use LifeBank;

create table lb_users
(
	user_id int primary key,
	name varchar(30) not null,
	last_name varchar(30) not null,
	user_name varchar(20) not null,
	pass varchar(20) not null,
	create_at date
);

create table lb_products
(
	id_prod int primary key,
	name varchar(30) not null,
	start_date date not null,
	end_date date not null,
	total numeric (8,2),
	debt numeric(8,2),
	interesrRate numeric(8,2),
	interestAmount numeric(8,2),
	user_id int not null
);

create table lb_transaction
(
	trans_id int primary key,
	trans_type tinyint not null,
	trans_date date not null,
	description varchar(50) not null,
	amount numeric(8,2) not null,
	id_prod int not null
);

create table lb_transaction_type
(
	trans_type_id tinyint primary key,
	description varchar(50) not null
);

alter table lb_transaction 
add foreign key (id_prod) references lb_products(id_prod);

alter table lb_products
add foreign key (user_id) references lb_users(user_id);

alter table lb_transaction
add foreign key (trans_type) references lb_transaction_type(trans_type_id);